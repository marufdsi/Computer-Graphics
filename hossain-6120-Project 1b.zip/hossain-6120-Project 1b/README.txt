1. First you have draw some primitives. By default it will be in draw mode.

2. To select a primitives, first click on the "Pick a Primitive" button. Then you can select 
any primitives. The selected primitive color will change to indicate the selection. If you another 
primitive the old primitive color will change to the original color. 

3. After select a primitive you perform left or right rotation. For this there is two button called 
"Rotate Left" and "Rotate Right".

4. To apply Scalling you have give some value in the text box beside "Scale" button, then click on 
the button.